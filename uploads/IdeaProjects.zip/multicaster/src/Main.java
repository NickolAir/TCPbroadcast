import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Properties;

public class Main {
    private static int PORT;
    private static InetAddress MC_GROUP;
    private static final String CFG_FILENAME = "config.properties";
    private static final String DEF_PORT = "1234";
    private static final String DEF_MC_GROUP = "230.0.0.0";
    private static void Init() {
        Properties properties = new Properties();
        try (InputStream fis = Main.class.getClassLoader().getResourceAsStream(CFG_FILENAME) ) {
            properties.load(fis);
        } catch (IOException e) {
            System.out.printf("Could not open file '%s'%n", CFG_FILENAME);
            System.exit(1);
        }
        try {
            PORT = Integer.parseInt(properties.getProperty("multicaster.port", DEF_PORT));
            System.out.printf("[CFG] using port '%d'%n", PORT);
        } catch (NumberFormatException e) {
            System.out.printf("[CFG] 'multicaster.port' value should be an integer, using default value (%s)%n", DEF_PORT);
            PORT = Integer.parseInt(DEF_PORT);
        }
        try {
            MC_GROUP = InetAddress.getByName(properties.getProperty("multicaster.group", DEF_MC_GROUP));
            System.out.printf("[CFG] using group '%s'%n", MC_GROUP);
        } catch (UnknownHostException e) {
            System.out.printf("[CFG] 'multicaster.group' value should be an known host, using default value (%s)%n", DEF_MC_GROUP);
            try {
                MC_GROUP = InetAddress.getByName(DEF_MC_GROUP);
            } catch (UnknownHostException ee) {
                System.out.println("Error occurred while trying to use default group");
                System.out.println(Arrays.toString(ee.getStackTrace()));
                System.exit(1);
            }
        }
    }
    public static void main(String[] args) {
        Init();
        try {
            Multicast multicast = new Multicast(Main.MC_GROUP, Main.PORT);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}