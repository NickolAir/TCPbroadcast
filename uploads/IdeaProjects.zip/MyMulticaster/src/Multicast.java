/*
import java.io.IOException;
import java.net.*;
import java.util.*;

public class Multicast {
    private static class CopyEntry {
        private final InetAddress address;
        private final int port;
        private long lastHeartbeat;
        public CopyEntry(InetAddress address, int port, long lastHeartbeat) {
            this.port = port;
            this.address = address;
            this.lastHeartbeat = lastHeartbeat;
        }
        public InetAddress getAddress() {
            return address;
        }
        public long getLastHeartbeat() {
            return lastHeartbeat;
        }

        public void setLastHeartbeat(long lastHeartbeat) {
            this.lastHeartbeat = lastHeartbeat;
        }
    }
    private final MulticastSocket listenSocket;
    private final DatagramSocket broadcastingSocket;
    private final InetAddress group;
    private final int port;
    private final InetAddress localAddr;
    private final List<CopyEntry> copies;
    private NetworkInterface networkInterface;
    public Multicast(InetAddress group, int port) throws IOException {
        this.group = group;
        this.port = port;

        System.out.println("please, choose a net interface");
        for (NetworkInterface ni : NetworkInterface.networkInterfaces().toList()) {
            System.out.println(ni.getDisplayName());
        }
        boolean chose = false;
        Scanner in = new Scanner(System.in);
        while(!chose) {
            String interf = in.nextLine();
            for (NetworkInterface ni : NetworkInterface.networkInterfaces().toList()) {
                if (ni.getDisplayName().equals(interf)) {
                    this.networkInterface = ni;
                    chose = true;
                    break;
                }
            }
            if (!chose) {
                System.out.println("no such interface, try again");
            }
        }

        this.listenSocket = new MulticastSocket(this.port);
        listenSocket.joinGroup(new InetSocketAddress(group, port), networkInterface);
        Thread receivingThread = new Thread(() -> {
            byte[] buf = new byte[256];
            while (true) {
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                try {
                    listenSocket.receive(p);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                String received = new String(p.getData(), 0, p.getLength());
                InetAddress from = p.getAddress();
                int copy_port = p.getPort();
                MessageReceived(received, from, copy_port);
            }
        });

        this.broadcastingSocket = new DatagramSocket();

        Thread sendingThread = new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                SendMessage("!hello!");
            }
        });


        // hacky(?) way to get local address
        try (final DatagramSocket datagramSocket = new DatagramSocket()) {
            datagramSocket.connect(InetAddress.getByName("8.8.8.8"), 12345);
            this.localAddr = datagramSocket.getLocalAddress();
        }
        System.out.printf("Local address: %s : %d%n", this.localAddr, this.port);
        this.copies = new ArrayList<>();

        Thread checkingThread = new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(3500);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                for (CopyEntry copy : this.copies) {
                    if (CheckTimeout(copy.address, copy.port)) {
                        OnTimeout(copy.address);
                    }
                }
            }
        });

        checkingThread.start();
        receivingThread.start();
        sendingThread.start();
    }
    private CopyEntry GetCopy(InetAddress address, int port) {
        for (CopyEntry copy : this.copies) {
            if (address.equals(copy.getAddress()) && port == copy.port) return copy;
        }
        return null;
    }
    private boolean HasACopy(InetAddress address) {
        for (CopyEntry copy : this.copies) {
            if (copy.getAddress().equals(address)) return true;
        }
        return false;
    }
    private boolean Heartbeat(InetAddress address, int port) {
        CopyEntry copy = GetCopy(address, port);
        Date now = new Date();
        if (copy == null) {
            copy = new CopyEntry(address, port, now.getTime());
            copies.add(copy);
            return true;
        }
        copy.setLastHeartbeat(now.getTime());
        return false;
    }
    private boolean CheckTimeout(InetAddress address, int port) {
        CopyEntry copy = GetCopy(address, port);
        if (copy == null) return false;
        Date now = new Date();
        boolean isTimeout = now.getTime() - copy.getLastHeartbeat() > 5000;
        if (isTimeout) {
            this.copies.remove(copy);
        }
        return isTimeout;
    }
    private void OnNewEntry(InetAddress newAddress) {
        System.out.printf("NEW COPY CONNECTED: %s%n%n", newAddress);
        PrintCopies();
    }
    private void OnTimeout(InetAddress address) {
        System.out.printf("COPY DISCONNECTED: %s%n%n", address);
        PrintCopies();
    }
    private void PrintCopies() {
        for (CopyEntry copy : copies) {
            System.out.printf("%s: last heartbeat %d%n", copy.getAddress(), copy.getLastHeartbeat());
        }
    }
    private void MessageReceived(String message, InetAddress from, int copy_port) {
        if (from.equals(this.localAddr) && this.port == copy_port) return;
        if (!message.equals("!hello!")) return;
        if (Heartbeat(from, copy_port)) {
            // new entry
            OnNewEntry(from);
        }
    }
    private void SendMessage(String message) {
        byte[] buf = message.getBytes();
        DatagramPacket p = new DatagramPacket(buf, buf.length, this.group, this.port);
        try {
            this.broadcastingSocket.send(p);
        } catch (IOException e) {
            System.out.printf("[snd] error while trying to broadcast message '%s'%n", message);
            System.out.println(Arrays.toString(e.getStackTrace()));
        }
    }
}
*/
