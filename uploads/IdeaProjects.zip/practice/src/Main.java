/*class LinealVector {
    private double x;
    private double y;
    private double z;
    public LinealVector (double x, double y, double z){
        this.x = x;
        this.y = y;
        this.z = z;
    }
    public double length (){
        return Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2) + Math.pow(z, 2));
    }
    public double multiplying (LinealVector vector){
        return x * vector.x + y * vector.y + z * vector.z;
    }
    public LinealVector vectorMultiplying (LinealVector vector){
        return new LinealVector(
                y * vector.z + z * vector.y,
                z * vector.x + x * vector.z,
                x * vector.y + y * vector.x);
    }
    public double cos (LinealVector vector){
        return multiplying(vector) / length() * vector.length();
    }
    public LinealVector[] generate (int N){
        LinealVector[] arrVectors = new LinealVector[N];
        for (int i = 0; i < N; i++){
            arrVectors[i] = new LinealVector(Math.random(), Math.random(), Math.random());
        }
        return arrVectors;
    }
    public String toString (LinealVector vector){
        return "Vector{" +
                "x=" + x +
                ", y=" + y +
                ", z=" + z +
                '}';
    }
}*/
public class Main {
    public static void main(String[] args) {
    }
}