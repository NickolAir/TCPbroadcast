import java.io.*;
import java.util.Objects;
import java.util.Scanner;
import java.util.Vector;
class CalcScanner{
    Scanner scanner;
    Vector<String> commands = new Vector<>();
    public CalcScanner(File fin){
        String s;
        try(FileReader reader = new FileReader(fin)){
            scanner = new Scanner(reader);
            do {
                s = scanner.nextLine();
                commands.addElement(s);
            } while(!Objects.equals(s, "PRINT"));
        }
        catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }
    public CalcScanner(){
        scanner = new Scanner(System.in);
        String s;
        do {
            s = scanner.nextLine();
            commands.addElement(s);
        } while(!Objects.equals(s, "PRINT"));
    }
    void linePrint(){
        String str = commands.toString();
        System.out.println(str);
    }
}
public class Main {
    public static void main(String[] args) {
        if (args.length == 0){
            System.out.println("Switched to manual input to the console");
            CalcScanner calcScanner = new CalcScanner();
            calcScanner.linePrint();
        } else {
            File fin = new File(args[0]);
            try{
                if(fin.exists()){
                    CalcScanner calcScanner = new CalcScanner(fin);
                    calcScanner.linePrint();
                }
                else{
                    throw new IOException("File not found");
                }
            }
            catch(IOException ex){
                System.out.println(ex.getMessage());
            }
        }
    }
}